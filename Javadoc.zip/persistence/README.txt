This is the data you can use to connect to the database externally


Username: UDLdhORRPs

Database name: UDLdhORRPs

Password: p7b2Q4EXzq

Server: remotemysql.com

Port: 3306
